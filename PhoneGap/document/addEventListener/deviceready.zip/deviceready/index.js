document.addEventListener("deviceready", myDeviceReady, false);

function myDeviceReady() {
	window.plugins.barcodeScanner.scan(mySuccess,myError);
}

function mySuccess(result) {
	alert("We got a barcode\n" + "Result: " + result.text + "\n" + "Format: " + result.format + "\n" +	"Cancelled: " + result.cancelled);
}

function myError(error) {
	alert("Scanning failed: " + error);
}
